package main

import "fmt"

func main() {
	fmt.Println(`abc"cba`, "123``321")
}
