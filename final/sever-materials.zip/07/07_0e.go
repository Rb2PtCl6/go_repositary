package main

import (
	"fmt"
)

func main() {
	a := [3]int{12, 78}
	fmt.Println(a) //  [12 78 0]
}
