package main

import (
	"fmt"
)

func main() {
	a := [...]int{12, 78, 50}
	fmt.Println(a) //  [12 78 50]
}
