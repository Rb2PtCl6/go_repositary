package main

import (
	"fmt"
)

func main() {
	var a [3]int
	a[0] = 12
	a[1] = 78
	a[2] = 50
	fmt.Println(a) //  [12 78 50]
}
