package main

import (
	"fmt"
)

func main() {
	a := [3]int{12, 78, 50}
	fmt.Println(a) //  [12 78 50]
}
