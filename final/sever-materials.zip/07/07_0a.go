package main

import (
	"fmt"
)

func main() {
	var a [3]int   //   массив из трёх int'ов
	fmt.Println(a) //   [0 0 0]
}
